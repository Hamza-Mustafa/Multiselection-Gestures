//
//  Data.swift
//  Multiselection Gestures Demo
//
//  Created by Amol Rai on 26/11/19.
//  Copyright © 2019 Amit Rai. All rights reserved.
//

import Foundation

struct Data {
    var number: Int
}
